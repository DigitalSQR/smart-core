### WHO Core Implementation Guide - Operations
